#ifndef MAIN_H
#define MAIN_H

#include <QtGlobal>

extern quint8 x, y;

#endif
