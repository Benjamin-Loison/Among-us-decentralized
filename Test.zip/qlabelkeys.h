#ifndef QLABELKEYS_H
#define QLABELKEYS_H

#include <QLabel>
#include <QEvent>
#include <QKeyEvent>
#include <QPainter>
#include "main.h"

class QLabelKeys : public QLabel
{
    Q_OBJECT

private:
    quint8 x, y;

public:
  void display()
  {
      QPixmap qPixmap = QPixmap("me.jpg");
      QPixmap qBackgroundPixmap = QPixmap("map.png");

      QPainter* painter = new QPainter(&qBackgroundPixmap);
      painter->drawPixmap(x, y, qPixmap);

      painter->end();
      setPixmap(qBackgroundPixmap);
  }

  QLabelKeys( QLabel *parent = 0 ) : QLabel( parent ) {
      x = 50;
      y = 50;
      display();
  }

protected:
  bool eventFilter( QObject *obj, QEvent *event )
  {
      //qInfo("ho");
      if (event->type()==QEvent::KeyPress) {
          //qInfo("ha");
              QKeyEvent* key = static_cast<QKeyEvent*>(event);
              if ( (key->key()==Qt::Key_Enter) || (key->key()==Qt::Key_Return) ) {
                  //Enter or return was pressed
                  //qInfo("hey");

                  x += 1;
                  display();
              } else {
                  return QObject::eventFilter(obj, event);
              }
              return true;
          } else {
              return QObject::eventFilter(obj, event);
          }
          return false; // static_cast from 'QEvent *' to 'QKeyEvent *', which are not related by inheritance, is not allowed
  }
};

#endif // QLABELKEYS_H
