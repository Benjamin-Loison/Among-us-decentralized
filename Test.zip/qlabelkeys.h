#ifndef QLABELKEYS_H
#define QLABELKEYS_H

#include <QLabel>
#include <QEvent>
#include <QKeyEvent>
#include <QPainter>
#include "main.h"

class QLabelKeys : public QLabel
{
    Q_OBJECT

    private:
        quint8 x, y;

    public:
      void display()
      {
          QPixmap qPixmap = QPixmap("me.jpg"),
                  qBackgroundPixmap = QPixmap("map.png");

          QPainter* painter = new QPainter(&qBackgroundPixmap);
          painter->drawPixmap(x, y, qPixmap);

          painter->end();
          setPixmap(qBackgroundPixmap);
      }

      QLabelKeys(QLabel* parent = 0) : QLabel(parent)
      {
          x = 50;
          y = 50;
          display();
      }

    protected:
        bool eventFilter(QObject* obj, QEvent* event)
        {
            Q_UNUSED(obj)

            if(event->type() == QEvent::KeyPress)
            {
                QKeyEvent* key = static_cast<QKeyEvent*>(event);
                switch(key->key())
                {
                    case Qt::Key_Down:
                        y++;
                        break;
                    case Qt::Key_Up:
                        y--;
                        break;
                    case Qt::Key_Left:
                        x--;
                        break;
                    case Qt::Key_Right:
                        x++;
                        break;
                }

                display();

                return true;
            }
            return false;
        }
};

#endif
