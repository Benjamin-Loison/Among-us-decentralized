#include <QApplication>
#include <QPushButton>
#include <QPalette>
#include <QColor>
#include <QLabel>
#include <QPainter>

#include "qlabelkeys.h"

quint8 x = 50, y = 50;

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    /*QPushButton bouton("Salut les Zéros, la forme ?");
    bouton.show();

    QPalette pal = bouton.palette();
    pal.setColor(QPalette::Button, QColor(Qt::blue));
    bouton.setAutoFillBackground(true);
    bouton.setPalette(pal);
    bouton.update();*/

    //qInfo("h");
    /*QLabel*/QLabelKeys* qLabel = new QLabelKeys/*QLabel*/;
    qLabel->installEventFilter(qLabel);

    qLabel->show();

    // QLabel, QPixmap, QPalette

    return app.exec();
}
